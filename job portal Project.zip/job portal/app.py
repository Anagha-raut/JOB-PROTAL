from flask import Flask, request, jsonify
import pyodbc

app = Flask(__name__)

conn_str = (
    'DRIVER={SQL Server};'
    'SERVER=LAPTOP-4HDAH66V\\SQLEXPRESS;'  # Replace with your server name
    'DATABASE=newDB;'  # Database name
    'UID=anu;'  # SQL Server username
    'PWD=12345;'  # Replace with your actual password
    'TrustServerCertificate=yes;'  # Trust certificate
)

def get_db_connection():
    conn = pyodbc.connect(conn_str)
    return conn

@app.route('/register', methods=['POST'])
def register():
    data = request.json
    name = data['name']
    email = data['email']
    password = data['pass']

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO login (Name, Email, Password) VALUES (?, ?, ?)", (name, email, password))
    conn.commit()
    conn.close()
    return jsonify({"message": "Registration successful!"})

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    email = data['email']
    password = data['pass']

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM login WHERE Email = ?", (email,))
    user = cursor.fetchone()
    conn.close()

    if user and user.Password == password:
        return jsonify({"message": "Login successful!"})
    else:
        return jsonify({"message": "Incorrect email or password!"}), 400

if __name__ == '__main__':
    app.run(host='localhost', port=5000)
