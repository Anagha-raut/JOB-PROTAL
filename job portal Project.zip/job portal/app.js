// const express = require('express');
// const sql = require('mssql');
// const bcrypt = require('bcryptjs');
// const bodyParser = require('body-parser');
// const path = require('path'); // Import path for serving static files

// const app = express();

// // Middleware to parse JSON and URL-encoded data
// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(bodyParser.json());

// // Serve static files from the public directory
// app.use(express.static(path.join(__dirname, 'public')));

// // Serve the home page on the root URL
// app.get('/', (req, res) => {
//   res.sendFile(path.join(__dirname, 'public', 'home.html')); // Change 'home.html' to the actual homepage filename if different
// });



// const sqlConfig = {
//     user: 'anu',
//     password: '12345',
//     database: 'newDB',
//     server: 'LAPTOP-4HDAH66V\\SQLEXPRESS',
//     options: {
//         encrypt: true,
//         trustServerCertificate: true,
//     }
// };

// async function testConnection() {
//     try {
//         await sql.connect(sqlConfig);
//         console.log("Connected to SQL Server successfully!");
//     } catch (err) {
//         console.error("Connection error: ", err);
//     } finally {
//         await sql.close();
//     }
// }

// testConnection();


// // Registration endpoint
// app.post('/register', async (req, res) => {
//     const { name, email, pass, c_pass } = req.body;

//     // Check if passwords match
//     if (pass !== c_pass) {
//         return res.status(400).send("Passwords do not match!");
//     }

//     // Hash the password
//     // const hashedPassword = await bcrypt.hash(pass, 10);

//     try {
//         // Connect to the database
//         await sql.connect(sqlConfig);
//         const result = await sql.query`INSERT INTO login (Name, Email, Password) VALUES (${name}, ${email}, ${pass})`;
//         res.send("Registration successful!");
//     } catch (err) {
//         res.status(500).send("Error: " + err);
//     }
// });

// // Login endpoint
// // Login endpoint
// app.post('/login', async (req, res) => {
//   const { email, pass } = req.body;

//   try {
//       // Connect to the database
//       await sql.connect(sqlConfig);
//       const result = await sql.query`SELECT * FROM login WHERE Email = ${email}`;

//       if (result.recordset.length === 0) {
//           return res.status(400).send("No account found with that email!");
//       }

//       const user = result.recordset[0];

//       // Check if the password matches directly
//       if (pass === user.Password) {
//           res.send("Login successful!");
//       } else {
//           res.status(400).send("Incorrect password!");
//       }
//   } catch (err) {
//       res.status(500).send("Error: " + err);
//   }
// });


// // Start the server
// app.listen(3000, () => {
//     console.log("Server is running on http://localhost:3000");
// });



const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();

// Middleware to parse JSON and URL-encoded data
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// Serve the home page on the root URL
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'home.html'));
});

// Registration endpoint (calls Python API)
app.post('/register', async (req, res) => {
    const { name, email, pass, c_pass } = req.body;

    if (pass !== c_pass) {?>
        return res.status(400).send("Passwords do not match!");
    }

    try {
        const response = await axios.post('http://localhost:5000/register', {
            name,
            email,
            pass
        });

        res.send(response.data.message);
    } catch (err) {
        res.status(500).send("Error: " + err.message);
    }
});

  
// Login endpoint (calls Python API)
app.post('/login', async (req, res) => {
    const { email, pass } = req.body;

    try {
        const response = await axios.post('http://localhost:5000/login', {
            email,
            pass
        });

        res.send(response.data.message);
    } catch (err) {
        res.status(500).send("Error: " + err.message);
    }
});

// Start the server
app.listen(3000, () => {
    console.log("Server is running on http://localhost:3000");
});
